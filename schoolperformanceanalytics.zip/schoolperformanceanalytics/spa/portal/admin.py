from django.contrib import admin
from .models import Contact
from .models import Students
from .models import Parent
from .models import AdminHOD
from .models import Staff
from .models import PortalParent


# Register your models here.
admin.site.register(Contact)
admin.site.register(Students)
admin.site.register(Parent)
admin.site.register(AdminHOD)
admin.site.register(Staff)
admin.site.register(PortalParent)