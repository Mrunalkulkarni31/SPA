from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Contact(models.Model):
     sno= models.AutoField(primary_key=True)
     name= models.CharField(max_length=255)
     email= models.CharField(max_length=100)
     subject= models.TextField(max_length=100)
     message= models.TextField(max_length=100)
     class Meta:
         db_table = "contact"

# class Students(models.Model):
#     Sr_No = models.AutoField(primary_key= True)
#     Stud_ID  = models.CharField(max_length= 100)
#     Stud_name  = models.CharField(max_length= 100)
#     Grnder  = models.TextField(max_length= 100)
#     Roll_no = models.CharField(max_length = 100)
#     Class = models.CharField(max_length= 100)
#     Division = models.TextField(max_length= 100)
#     parent = models.ForeignKey(User, on_delete = models.CASCADE)
#     def __str__(self):
#         return self.Stud_name


class AdminHOD(models.Model):
    id = models.AutoField(primary_key=True)
    admin = models.OneToOneField(User, on_delete = models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()


class Students(models.Model):
    id = models.AutoField(primary_key=True)
    # admin = models.OneToOneField(User, on_delete = models.CASCADE)
    gender = models.CharField(max_length=50)
    profile_pic = models.FileField()
    address = models.TextField()
    parents_id = models.ForeignKey(User, on_delete = models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()



class Parent(models.Model):
    parent_id  = models.AutoField(primary_key= True)
    Mother_name  = models.CharField(max_length= 100)
    Father_name  = models.CharField(max_length= 100)
    Mother_Education = models.TextField(max_length= 100)
    Father_Education = models.TextField(max_length= 100)
    Mother_Profession= models.CharField(max_length = 100)
    father_Profession = models.CharField(max_length= 100)
    Division = models.TextField(max_length= 100)
    def __str__(self):
        return self.Parent_ID 

class Staff(models.Model):
    id = models.AutoField(primary_key=True)
    admin = models.OneToOneField(User, on_delete = models.CASCADE)
    address = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()

class PortalParent(models.Model):
    sr_no = models.AutoField(db_column='Sr_No', primary_key=True)  # Field name made lowercase.
    parent_id = models.CharField(db_column='Parent_ID', max_length=100)  # Field name made lowercase.
    mother_name = models.CharField(db_column='Mother_name', max_length=100)  # Field name made lowercase.
    father_name = models.CharField(db_column='Father_name', max_length=100)  # Field name made lowercase.
    mother_education = models.TextField(db_column='Mother_Education')  # Field name made lowercase.
    father_education = models.TextField(db_column='Father_Education')  # Field name made lowercase.
    mother_profession = models.CharField(db_column='Mother_Profession', max_length=100)  # Field name made lowercase.
    father_profession = models.CharField(db_column='father_Profession', max_length=100)  # Field name made lowercase.
    division = models.TextField(db_column='Division')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'portal_parent'  










class Profile:
    name = str
    id = int
    Class = str
    section = str
    Roll = int
    academic = int
    Gender = str
    blood = str
