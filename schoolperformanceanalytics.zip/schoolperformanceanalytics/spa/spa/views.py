from django.shortcuts import render,HttpResponse,redirect
from django.contrib import messages
from portal.models import Contact
from django.contrib.auth.models import User,auth
from portal.models import Profile


def home(request):
    return render(request, 'home.html')


def about(request):
    return HttpResponse('about')

def contact(request):
    if request.method == "POST":
        if request.POST.get('name') and request.POST.get('email') and request.POST.get('subject') and request.POST.get('message'):
            saverecord = Contact()
            saverecord.name = request.POST.get('name')
            saverecord.email = request.POST.get('email')
            saverecord.subject = request.POST.get('subject')
            saverecord.message = request.POST.get('message')
            saverecord.save()
        # entry = contact(name=name, email = email, subject = subject, message = message )
        # models.session.add(entry)
        # models.session.commit()
        # print(name,email,subject,message)

        return render(request, 'home.html')

def login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username = username,password = password)

        if user is not None:
            auth.login(request,user)
            return redirect('profile')
        else:
            return HttpResponse("Invalid credentials!")
    else:
        return render(request, 'login.html')

def studentpa(request):
    return render(request, 'studentpa.html')

def profile(request):
    prof = Profile()
    prof.name = 'Sahil'
    prof.id = 'ETH20'
    prof.Class = '8th'
    prof.section = 'A'
    prof.roll = '20'
    prof.academic = '2021'
    prof.gender = 'Male'
    prof.blood = 'O+ve'



    return render(request, "profile.html", {'prof': prof })
